#!/bin/sh
#
# Place applications to be executed when WindowMaker is started here.
# This should only be used for non-X applications or applications that
# do not support session management. Other applications should be restarted
# by the WindowMaker session restoring mechanism. For that, you should
# either set SaveSessionOnExit=YES or select "Save Session" in the Workspace
# submenu of the root menu when all applications you want started are
# running.
#
# WindowMaker will wait until this script finishes, so if you run any
# commands that take long to execute (like a xterm), put a ``&'' in the
# end of the command line.
#
# This file must be executable.
#

setxkbmap fr

if (test -e /tmp/tmp_vnc)
then
	vncviewer &
fi

if (test -e /tmp/tmp_oscarx)
then
#	xterm /usr/share/oscar/bin/oscar &
	mrxvt -e oscar &
fi

if (test -e /tmp/gp)
then
	gparted &
fi


if (test -e /tmp/qt)
then
	qtparted &
fi

#if (test -e /tmp/links)
#then
#	links2 -g -language french /usr/share/oscar/usr/favoris.htm
#fi
	
